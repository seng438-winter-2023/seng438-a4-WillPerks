package org.jfree.data;

import static org.junit.Assert.*;

import org.junit.Test;

public class DataUtilitiesEqualTest {

	@Test
	public void testingWithNull2DArrays() {
		double[][]a = null;
		double[][]b = null;
		assertTrue(DataUtilities.equal(a, b));
	}
	
	@Test(expected = Exception.class)
	public void testingWithArrayWithNullValues() {
		double[][]a = {{(Double) null}};
		double[][]b = {{(Double) null}};
		assertFalse(DataUtilities.equal(a, b));
	}
	
	@Test
	public void testingWhenFirstIsNullandSecondIsNotNull() {
		double[][]a = {{1.0}};
		double[][]b =  null;
		assertFalse(DataUtilities.equal(a, b));
	}
	
	@Test
	public void testingWhenFirstIsNotNullandSecondIsNNull() {
		double[][]a = null;
		double[][]b =  {{1.0}};
		assertFalse(DataUtilities.equal(a, b));
	}
	
	
	@Test
	public void testingWhenFirstIsDifferentFromSecondButHaveSameLength() {
		double[][]a = {{1.0}, {1.0}, {1.0}};
		double[][]b = {{1.0}, {2.0}, {3.0}};
		assertFalse(DataUtilities.equal(a, b));
	}
	
	
	@Test
	public void testingWithOuterArrayHavingInnerNullArrays() {
		double[][]a = {null, null};
		double[][]b = {null,null};
		assertTrue(DataUtilities.equal(a, b));
	}
	
	@Test
	public void testingWithEmpty2dArray() {
		double[][]a = {};
		double[][]b = {};
		assertTrue(DataUtilities.equal(a, b));
	}
	
	@Test
	public void testingWithSmallArray() {
		double[][]a = {{1.0}};
		double[][]b = {{1.0}};
		assertTrue(DataUtilities.equal(a, b));
	}
	
	
	@Test
	public void testingWithLargeArray() {
		double[][]a = {{1.0}, {1.0}, {1.0}};
		double[][]b = {{1.0}, {2.0}, {1.0}, {1.0}};
		assertFalse(DataUtilities.equal(a, b));
	}
	
	@Test
	public void testingWithArraysOfDifferentLength() {
		double[][]a = {{1.0}, {1.0}, {1.0}};
		double[][]b = {{1.0}, {1.0}};
		assertFalse(DataUtilities.equal(a, b));
	}
	
	@Test
	public void testingWithArraysOfDifferentArrays() {
		double[][]a = {{1.0}, {1.0}, {1.0}};
		double[][]b = {{2.0, 2.0}};
		assertFalse(DataUtilities.equal(a, b));
	}
	

}
